/*
 * Nonattacking n-by-m Queens Solver
 * Wood, Zachary
 * March 1st, 2024
 * 
 * This program uses a recursive method for search for valid queen placements.
 */

//Necessary imports
import java.util.ArrayList;
import java.lang.Math;
import java.util.Scanner;

public class nonattackingQueens 
{
	//An ArrayList stores valid queens, with its indices representing rows and
	//values representing corresponding columns.
	static ArrayList<Integer> queens = new ArrayList<Integer>();
	//A minor quality of life enhancer which numbers solutions
	static int count;
	
	
	/**
	 * Main method which launhces the program
	 * @param args
	 */
	public static void main(String[] args) 
	{
		//Scanner for user input and boolean for terminating the program
		Scanner scan = new Scanner(System.in);
		boolean cont = true;
		
		
		//Explanation of the program and its functionality. n determines the
		//number of queens because the recursiveQueens method starts with rows
		System.out.println("Bienvenidos, amigos!\nThis is an n by m queens "
				+ "solution generator. It generates all symmetries rather than"
				+ " unique solutions.\nIf using inequivalent n and m values "
				+ "for non-square boards, use the lower value for the rows: "
				+ "that is how the number of queens is determined!");
		
		//while loop for terminating the program
		while (cont)
		{
			//Scanner requests user inputs for the chessboard dimensions
			System.out.print("\nNumber of rows (n): ");
			int n = scan.nextInt();
			System.out.print("\nNumber of rows (m): ");
			int m = scan.nextInt();
			
			//calls the recursive method for solving the chessboard
			recursiveQueens(n,m,1);
			
			//resets the count 
			count = 0;
			
			//asks if user would like to continue the program and stores answer
			System.out.println("Would you like to continue? Type n for no!");
			String answer = scan.next();
			
			//if answer is n, quit the loop and terminate the program
			if (answer.equals("n"))
			{
				cont = false;
			}
			//do nothing otherwise, preserving the loop
		}
	}
	
	
	/**
	 * method for checking the validity of queen positions (row, column)
	 * @param row
	 * @param column
	 * @return
	 */
	public static boolean checkValid(int row, int column)
	{
		//initializes the validity of the queen position as true
		boolean valid = true;
		
		//for loop for checking if the new queen is in danger from any others
		//rows are not checked because each queen is stored in a new row
		for (int i = 0; i < queens.size(); i++)
		{
			//checks for shared columns
			if (queens.get(i) == column)
			{
				valid = false;
			}
			
			//checks for shared diagonals (using right triangles)
			if (Integer.compare(Math.abs(column - queens.get(i)), Math.abs(row - (i + 1))) == 0)
			{
				valid = false;
			}
		}
		
		return valid;
	}
	
	
	/**
	 * Recursive method for finding valid queen positions.
	 * base case: currentRow == 0: all solutions found, end method
	 * general case: currentRow == rowSize + 1; print current solution and continue
	 * general case: check each column and row for valid queen positions
	 * 
	 * @param rowSize
	 * @param columnSize
	 * @param currentRow
	 */
	public static void recursiveQueens(int rowSize, int columnSize, int currentRow)
	{
		//base case
		if (currentRow == 0)
		{
			//if no solutions were found, notify the client.
			//otherwise, end the method.
			if (count == 0)
			{
				System.out.println("No solutions for your input!");
			}
		}
		//first general case
		else if (currentRow == rowSize + 1)
		{
			//print the current solution
			printSolution(queens, columnSize);
			
			//remove the last queen added before continuing the search
			queens.remove(queens.size() - 1);
		}
		//second general case
		else
		{
			//checks each column of the current row for valid queen positions
			for (int i = 1; i <= columnSize; i++)
			{
				//calls checkValid to see if current queen position is valid
				if (checkValid(currentRow, i) == true)
				{
					//if valid, add the queen
					queens.add(i);
					
					//RECURSIVE CALL to beging checking the next row
					recursiveQueens(rowSize, columnSize, currentRow + 1);
				}
			}
			
			//after checking every column, return to the previous row and 
			//remove the last queen added, if any
			if (queens.size() > 0)
			{
				queens.remove(queens.size() - 1);
			}
		}
	}

	
	/**
	 * prints the solution based on the dimensions of the chessboard
	 * 
	 * @param queens
	 * @param column
	 */
	public static void printSolution(ArrayList<Integer> queens, int column)
	{
		//increases the count for each solution
		count++;
		
		//labels each solution
		System.out.println("Solution " + count + ": ");
		
		//iterates through each row of the chessboard
		for (int i = 0; i < queens.size(); i++)
		{
			//iterates through each column of the chessboard for empty spaces
			for (int n = 1; n < queens.get(i); n++)
			{
				System.out.print("O ");
			}
			
			//prints an X for the position of the queen
			System.out.print("X");
			
			//iterates through each column of the chessboard for empty spaces
			for (int n = queens.get(i); n < column; n++)
			{
				System.out.print(" O");
			}
			
			//seperates each row
			System.out.println("");
		}
		
		//seperates each solution
		System.out.println("");
	}
}
